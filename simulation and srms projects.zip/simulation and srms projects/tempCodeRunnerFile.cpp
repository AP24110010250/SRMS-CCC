// srms_single.cpp
// SRMS (single file) - plain-text passwords (no encryption)

#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <string>
#include <algorithm>
#include <cctype>

using namespace std;

const string CREDENTIALS_FILE = "credentials.txt";
const string STUDENT_FILE     = "student.txt";

string currentRole = "GUEST";
string currentUser = "guest";

// ---------- helpers ----------
void trimNewline(string &s) {
    while (!s.empty() && (s.back() == '\n' || s.back() == '\r'))
        s.pop_back();
}

void readLine(const string &prompt, string &out) {
    cout << prompt;
    getline(cin, out);
    trimNewline(out);
}

int readInt(const string &prompt) {
    string buf;
    int val;
    while (true) {
        readLine(prompt, buf);
        stringstream ss(buf);
        if (ss >> val) return val;
        cout << "Invalid integer — try again.\n";
    }
}

float readFloat(const string &prompt) {
    string buf;
    float val;
    while (true) {
        readLine(prompt, buf);
        stringstream ss(buf);
        if (ss >> val) return val;
        cout << "Invalid number — try again.\n";
    }
}

void sanitizePipe(string &s) {
    for (char &c : s) if (c == '|') c = ' ';
}

// ---------- credential helpers (plain text) ----------
string check_user(const string &username) {
    ifstream fin(CREDENTIALS_FILE);
    if (!fin) return "";
    string u, pass, role;
    while (fin >> u >> pass >> role) {
        if (u == username) return pass;
    }
    return "";
}

bool check_pass3times_with_plain(const string &stored_pass) {
    string password;
    for (int i = 3; i >= 1; --i) {
        cout << "enter your password (" << i << " left): ";
        getline(cin, password);
        if (password == stored_pass) return true;
        cout << "wrong password, number of attempts = " << (i - 1) << endl;
    }
    cout << "your login failed, please try again later\n";
    return false;
}

// ---------- forward declarations ----------
int loginSystem();
void create_account();
void change_password();
void delete_account();

void mainMenu();
void adminMenu();
void staffMenu();
void guestMenu();

bool rollExists(int roll);
bool nameExists(const string &name);
bool nameExistsExceptRoll(const string &name, int roll);
void addStudent();
void displayStudents();
void searchStudent();
void updateStudent();
void deleteStudent();

// ---------- start menu / login ----------
int loginSystem() {
    string username, password;

    while (true) {
        cout << "\n====== WELCOME TO SRMS ======\n";
        cout << "1. Login\n";
        cout << "2. Create Account\n";
        cout << "3. Exit\n";

        int choice = readInt("Enter choice: ");

        if (choice == 1) {
            int attempts = 3;
            while (attempts > 0) {
                cout << "\n========= LOGIN SCREEN =========\n";
                cout << "Attempts remaining: " << attempts << "\n";

                readLine("Username: ", username);
                readLine("Password: ", password);

                ifstream fin(CREDENTIALS_FILE);
                if (!fin) {
                    cout << "credentials.txt missing — logging in as ADMIN (dev mode)\n";
                    currentRole = "ADMIN";
                    currentUser = "localadmin";
                    return 1;
                }

                bool ok = false;
                string fileUser, filePass, fileRole;
                while (fin >> fileUser >> filePass >> fileRole) {
                    if (fileUser == username && filePass == password) {
                        currentUser = fileUser;
                        currentRole = fileRole;
                        ok = true;
                        break;
                    }
                }
                fin.close();

                if (ok) {
                    cout << "Login successful! Welcome " << currentUser << " (" << currentRole << ")\n";
                    return 1;
                }

                attempts--;
                if (attempts == 0) {
                    cout << "Login failed. Returning to start menu.\n";
                } else {
                    cout << "Invalid credentials. Try again.\n\n";
                }
            }
        }
        else if (choice == 2) {
            create_account();
        }
        else if (choice == 3) {
            return 0;
        }
        else {
            cout << "Invalid selection.\n";
        }
    }
}

// ---------- account management ----------
void create_account() {
    string user, pass, role;
    cout << "---- Create new account ----\n";
    readLine("New Username: ", user);
    if (!check_user(user).empty()) {
        cout << "Username already exists.\n";
        return;
    }
    readLine("New Password: ", pass);
    readLine("Role (ADMIN/STAFF/GUEST): ", role);
    for (char &c : role) c = toupper((unsigned char)c);
    if (role != "ADMIN" && role != "STAFF" && role != "GUEST") role = "GUEST";

    ofstream fout(CREDENTIALS_FILE, ios::app);
    if (!fout) { cout << "Error opening credentials file.\n"; return; }
    fout << user << " " << pass << " " << role << "\n";
    fout.close();
    cout << "Account created!\n";
}

void change_password() {
    string user;
    readLine("Enter username: ", user);
    string stored = check_user(user);
    if (stored.empty()) { cout << "User not found.\n"; return; }

    if (!check_pass3times_with_plain(stored)) { cout << "Old password not verified. Cancelling.\n"; return; }

    string newpass;
    readLine("Enter new password: ", newpass);

    ifstream fin(CREDENTIALS_FILE);
    ofstream fout("temp_cr.txt");
    if (!fin || !fout) { cout << "Error opening credential files.\n"; return; }
    string u, p, r;
    while (fin >> u >> p >> r) {
        if (u == user) fout << u << " " << newpass << " " << r << "\n";
        else fout << u << " " << p << " " << r << "\n";
    }
    fin.close(); fout.close();
    remove(CREDENTIALS_FILE.c_str());
    rename("temp_cr.txt", CREDENTIALS_FILE.c_str());
    cout << "Password changed.\n";
}

void delete_account() {
    string user;
    readLine("Enter username to delete: ", user);
    string stored = check_user(user);
    if (stored.empty()) { cout << "User not found.\n"; return; }

    if (!check_pass3times_with_plain(stored)) { cout << "Password not verified. Aborting.\n"; return; }

    ifstream fin(CREDENTIALS_FILE);
    ofstream fout("temp.txt");
    if (!fin || !fout) { cout << "Error opening credential files.\n"; return; }
    string u, p, r;
    bool found = false;
    while (fin >> u >> p >> r) {
        if (u == user) { found = true; continue; }
        fout << u << " " << p << " " << r << "\n";
    }
    fin.close(); fout.close();
    remove(CREDENTIALS_FILE.c_str());
    rename("temp.txt", CREDENTIALS_FILE.c_str());
    if (found) cout << "Account deleted.\n"; else cout << "No such account.\n";
}

// ---------- student functions ----------
bool rollExists(int roll) {
    ifstream fin(STUDENT_FILE);
    if (!fin) return false;
    string line;
    while (getline(fin, line)) {
        trimNewline(line);
        if (line.empty()) continue;
        size_t p = line.find('|');
        if (p == string::npos) continue;
        int r = 0;
        try { r = stoi(line.substr(0, p)); } catch(...) { continue; }
        if (r == roll) return true;
    }
    return false;
}

bool nameExists(const string &name) {
    ifstream fin(STUDENT_FILE);
    if (!fin) return false;
    string lowered = name;
    for (char &c : lowered) c = tolower((unsigned char)c);
    string line;
    while (getline(fin, line)) {
        trimNewline(line);
        if (line.empty()) continue;
        size_t p1 = line.find('|');
        size_t p2 = line.find('|', p1 + 1);
        if (p1 == string::npos || p2 == string::npos) continue;
        string n = line.substr(p1 + 1, p2 - p1 - 1);
        string nn = n;
        for (char &c : nn) c = tolower((unsigned char)c);
        if (nn == lowered) return true;
    }
    return false;
}

bool nameExistsExceptRoll(const string &name, int roll) {
    ifstream fin(STUDENT_FILE);
    if (!fin) return false;
    string lowered = name;
    for (char &c : lowered) c = tolower((unsigned char)c);
    string line;
    while (getline(fin, line)) {
        trimNewline(line);
        if (line.empty()) continue;
        size_t p1 = line.find('|');
        size_t p2 = line.find('|', p1 + 1);
        if (p1 == string::npos || p2 == string::npos) continue;
        int r = 0;
        try { r = stoi(line.substr(0, p1)); } catch(...) { continue; }
        if (r == roll) continue;
        string n = line.substr(p1 + 1, p2 - p1 - 1);
        string low2 = n;
        for (char &c : low2) c = tolower((unsigned char)c);
        if (low2 == lowered) return true;
    }
    return false;
}

void addStudent() {
    int roll = readInt("\nEnter Roll: ");
    if (rollExists(roll)) {
        cout << "A student with roll " << roll << " already exists. Choose another roll.\n";
        return;
    }
    string name;
    readLine("Enter Name (can include spaces): ", name);
    sanitizePipe(name);
    if (nameExists(name)) {
        cout << "A student with the name \"" << name << "\" already exists. Choose a different name.\n";
        return;
    }
    float marks = readFloat("Enter Marks: ");
    ofstream fout(STUDENT_FILE, ios::app);
    if (!fout) { cout << "Error opening student file.\n"; return; }
    fout << roll << "|" << name << "|" << fixed << setprecision(2) << marks << "\n";
    fout.close();
    cout << "Student Added Successfully!\n";
}

void displayStudents() {
    ifstream fin(STUDENT_FILE);
    if (!fin) { cout << "No student records found (file missing).\n"; return; }
    cout << "\n" << left << setw(6) << "Roll" << " " << setw(30) << "Name" << " " << right << setw(8) << "Marks\n";
    cout << "---------------------------------------------------------------\n";
    string line;
    while (getline(fin, line)) {
        trimNewline(line);
        if (line.empty()) continue;
        size_t p1 = line.find('|');
        size_t p2 = line.find('|', p1 + 1);
        if (p1 == string::npos || p2 == string::npos) continue;
        int roll = 0;
        try { roll = stoi(line.substr(0, p1)); } catch(...) { continue; }
        string name = line.substr(p1 + 1, p2 - p1 - 1);
        float marks = 0.0f;
        try { marks = stof(line.substr(p2 + 1)); } catch(...) { marks = 0.0f; }
        cout << left << setw(6) << roll << " " << setw(30) << name << " " << right << setw(8) << fixed << setprecision(2) << marks << "\n";
    }
    fin.close();
}

void searchStudent() {
    cout << "\nSearch by:\n1. Roll\n2. Name (partial, case-insensitive)\n";
    int mode = readInt("Enter choice: ");
    if (mode == 1) {
        int key = readInt("Enter Roll to search: ");
        ifstream fin(STUDENT_FILE);
        if (!fin) { cout << "No student records.\n"; return; }
        string line;
        bool found = false;
        while (getline(fin, line)) {
            trimNewline(line);
            if (line.empty()) continue;
            size_t p1 = line.find('|');
            size_t p2 = line.find('|', p1 + 1);
            if (p1 == string::npos || p2 == string::npos) continue;
            int roll = 0;
            try { roll = stoi(line.substr(0, p1)); } catch(...) { continue; }
            if (roll == key) {
                string name = line.substr(p1 + 1, p2 - p1 - 1);
                float marks = 0.0f;
                try { marks = stof(line.substr(p2 + 1)); } catch(...) { marks = 0.0f; }
                cout << "\nRecord Found:\nRoll: " << roll << "\nName: " << name << "\nMarks: " << fixed << setprecision(2) << marks << "\n";
                found = true; break;
            }
        }
        fin.close();
        if (!found) cout << "Record not found.\n";
    } else if (mode == 2) {
        string query; readLine("Enter name or part of name to search: ", query);
        for (char &c : query) c = tolower((unsigned char)c);
        ifstream fin(STUDENT_FILE);
        if (!fin) { cout << "No student records.\n"; return; }
        string line;
        bool found = false;
        cout << "\nMatches:\n" << left << setw(6) << "Roll" << " " << setw(30) << "Name" << " " << right << setw(8) << "Marks\n";
        cout << "---------------------------------------------------------------\n";
        while (getline(fin, line)) {
            trimNewline(line);
            if (line.empty()) continue;
            size_t p1 = line.find('|');
            size_t p2 = line.find('|', p1 + 1);
            if (p1 == string::npos || p2 == string::npos) continue;
            int roll = 0;
            try { roll = stoi(line.substr(0, p1)); } catch(...) { continue; }
            string name = line.substr(p1 + 1, p2 - p1 - 1);
            string lowerName = name; for (char &c : lowerName) c = tolower((unsigned char)c);
            if (lowerName.find(query) != string::npos) {
                float marks = 0.0f;
                try { marks = stof(line.substr(p2 + 1)); } catch(...) { marks = 0.0f; }
                cout << left << setw(6) << roll << " " << setw(30) << name << " " << right << setw(8) << fixed << setprecision(2) << marks << "\n";
                found = true;
            }
        }
        fin.close();
        if (!found) cout << "No matching records found.\n";
    } else {
        cout << "Invalid choice.\n";
    }
}

void updateStudent() {
    int key = readInt("Enter Roll to update: ");
    ifstream fin(STUDENT_FILE);
    ofstream temp("temp.txt");
    if (!fin || !temp) { if (fin) fin.close(); if (temp) temp.close(); cout << "Error opening files.\n"; return; }
    string line;
    bool found = false;
    while (getline(fin, line)) {
        trimNewline(line);
        if (line.empty()) continue;
        size_t p1 = line.find('|');
        size_t p2 = line.find('|', p1 + 1);
        if (p1 == string::npos || p2 == string::npos) { temp << line << "\n"; continue; }
        int roll = 0;
        try { roll = stoi(line.substr(0, p1)); } catch(...) { temp << line << "\n"; continue; }
        string name = line.substr(p1 + 1, p2 - p1 - 1);
        float marks = 0.0f;
        try { marks = stof(line.substr(p2 + 1)); } catch(...) { marks = 0.0f; }
        if (roll == key) {
            cout << "Current -> Roll:" << roll << " Name:" << name << " Marks:" << fixed << setprecision(2) << marks << "\n";
            string newName; readLine("Enter new Name (can include spaces): ", newName);
            sanitizePipe(newName);
            if ((newName != name) && nameExistsExceptRoll(newName, roll)) {
                cout << "A student with the name \"" << newName << "\" already exists. Update cancelled.\n";
                temp << line << "\n";
            } else {
                float newMarks = readFloat("Enter new Marks: ");
                temp << roll << "|" << newName << "|" << fixed << setprecision(2) << newMarks << "\n";
                found = true;
            }
        } else {
            temp << line << "\n";
        }
    }
    fin.close(); temp.close();
    remove(STUDENT_FILE.c_str());
    rename("temp.txt", STUDENT_FILE.c_str());
    if (found) cout << "Record updated.\n"; else cout << "Record not found or update cancelled.\n";
}

void deleteStudent() {
    int key = readInt("Enter Roll to delete: ");
    ifstream fin(STUDENT_FILE);
    ofstream temp("temp.txt");
    if (!fin || !temp) { if (fin) fin.close(); if (temp) temp.close(); cout << "Error opening files.\n"; return; }
    string line;
    bool found = false;
    while (getline(fin, line)) {
        trimNewline(line);
        if (line.empty()) continue;
        size_t p1 = line.find('|');
        if (p1 == string::npos) { temp << line << "\n"; continue; }
        int roll = 0;
        try { roll = stoi(line.substr(0, p1)); } catch(...) { temp << line << "\n"; continue; }
        if (roll == key) { found = true; continue; }
        temp << line << "\n";
    }
    fin.close(); temp.close();
    remove(STUDENT_FILE.c_str());
    rename("temp.txt", STUDENT_FILE.c_str());
    if (found) cout << "Record deleted.\n"; else cout << "Record not found.\n";
}

// ---------- menus ----------
void adminMenu() {
    while (true) {
        cout << "\n====== ADMIN MENU ======\n";
        cout << "1. Add Student\n2. Display Students\n3. Search Student\n4. Update Student\n5. Delete Student\n";
        cout << "6. Create Account\n7. Change Password\n8. Delete Account\n9. Logout\n";

        int c = readInt("Enter choice: ");

        if (c == 1) addStudent();
        else if (c == 2) displayStudents();
        else if (c == 3) searchStudent();
        else if (c == 4) updateStudent();
        else if (c == 5) deleteStudent();
        else if (c == 6) create_account();
        else if (c == 7) change_password();
        else if (c == 8) delete_account();
        else if (c == 9) break;
        else cout << "Invalid choice.\n";
    }
}

void staffMenu() {
    while (true) {
        cout << "\n====== STAFF MENU ======\n";
        cout << "1. Add Student\n2. Display Students\n3. Search Student\n4. Logout\n";

        int c = readInt("Enter choice: ");

        if (c == 1) addStudent();
        else if (c == 2) displayStudents();
        else if (c == 3) searchStudent();
        else if (c == 4) break;
        else cout << "Invalid choice.\n";
    }
}

void guestMenu() {
    while (true) {
        cout << "\n====== GUEST MENU ======\n";
        cout << "1. Display Students\n2. Search Student\n3. Logout\n";

        int c = readInt("Enter choice: ");

        if (c == 1) displayStudents();
        else if (c == 2) searchStudent();
        else if (c == 3) break;
        else cout << "Invalid choice.\n";
    }
}

void mainMenu() {
    if (currentRole == "ADMIN") adminMenu();
    else if (currentRole == "STAFF") staffMenu();
    else guestMenu();
}

// ---------- main ----------
int main() {
    cout << "SRMS starting...\n";
    if (loginSystem()) mainMenu();
    else cout << "Login failed. Exiting program.\n";
    cout << "Goodbye.\n";
    return 0;
}